<?php $__env->startSection('title', 'Create a News story'); ?>
<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<form action="<?php echo e(url('create')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<section>
<h1>Create a News story</h1>
<p>Fill in the form below to add a new news story.</p>
<label for="title">Title:</label>
<input type="text" id="title" name="title">
<label for="content">Content:</label>
<input type="text" id="content" name="content">
<label for="timestamps">Timestamps:</label>
<input type="date" id="timestamps" name="timestamps">
<input type="submit" name="submitBtn" value="Add News story">
</form>
<br>
<br>
<footer>News story administartion system @2019</footer>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>