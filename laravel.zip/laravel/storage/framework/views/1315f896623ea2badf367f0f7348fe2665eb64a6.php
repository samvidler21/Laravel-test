<?php $__env->startSection('title', 'Delete a News story'); ?>

<?php $__env->startSection('content'); ?>
<section>

  <h1>Delete a  News story</h1>
    <p>Below are all the news stories where you can select which one you would like to delete</p>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>