<?php $__env->startSection('title', 'View All News'); ?>

<?php $__env->startSection('content'); ?>
<section>
    <h1>View All News</h1>
    <p>View all the news stories below.</p>
</section>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>