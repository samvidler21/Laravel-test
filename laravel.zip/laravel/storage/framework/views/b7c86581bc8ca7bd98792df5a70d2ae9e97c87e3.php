<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" type="text/css">
    </head>
    <body>
        <?php $__env->startSection('header'); ?>
            <ul>
                <li><a href="<?php echo e(url('list')); ?>">View all news</a></li>
                <li><a href="<?php echo e(url('create')); ?>">Create a news story</a></li>
                  <li><a href="<?php echo e(url('update')); ?>">Update a news story</a></li>
                <li><a href="<?php echo e(url('delete')); ?>">Delete a news story </a></li>
            </ul>
        <?php echo $__env->yieldSection(); ?>

        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>
