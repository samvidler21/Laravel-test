<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\News;

class NewsController extends Controller
{
  function index()
    {
        return view('news/list-view');
    }
    function create()
    {
        return view('news/create-view');
    }
    function save(Request $request){
    $this->validate($request, [
        'title' => 'required|max:100',
        'content' => 'required|max:1000',
        'timestamps' => 'required',
    ]);
    $news = new News();
    $news->title = $request->title;
    $news->content=$request->content;
    $news->timestamps=$request->timestamps;
    $news->save();
    return redirect('list');

    return JsonResponse::create($aResult);
}
    function update()
    {
        return view('news/update-view');
    }
    function updatenews(Request $request)
    {
      news::destroy($request->news);
      return redirect('list');
    }
    function delete()
    {
        return view('news/delete-view');
    }
function deletenews(Request $request)
{
  news::destroy($request->news);
  return redirect('list');
}
}
