<?php

use Illuminate\Database\Seeder;

class NewsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('news')->insert(['title' => 'PM resigns','content' => 'Prime minister Boris Johnson resigns', 'timestrap'=>06/10/2000]);
    }
}
