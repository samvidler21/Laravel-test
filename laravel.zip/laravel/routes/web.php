<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('list', 'NewsController@index');
Route::get('create','NewsController@create');
Route::post('save','NewsController@save');
Route::get('update','NewsController@update');
Route::post('updatenews','NewsController@updatenews');
Route::get('delete','NewsController@delete');
Route::post('deletenews','NewsController@deletenews');
