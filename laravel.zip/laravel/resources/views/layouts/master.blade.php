<html>
    <head>
        <title>@yield('title')</title>
        <link href="{{asset('/css/style.css')}}" rel="stylesheet" type="text/css">
    </head>
    <body>
        @section('header')
            <ul>
                <li><a href="{{url('list')}}">View all news</a></li>
                <li><a href="{{url('create')}}">Create a news story</a></li>
                  <li><a href="{{url('update')}}">Update a news story</a></li>
                <li><a href="{{url('delete')}}">Delete a news story </a></li>
            </ul>
        @show

        <div class="container">
            @yield('content')
        </div>
    </body>
</html>
