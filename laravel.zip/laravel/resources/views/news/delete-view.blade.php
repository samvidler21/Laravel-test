@extends('layouts.master')

@section('title', 'Delete a News story')

@section('content')
<section>

  <h1>Delete a  News story</h1>
    <p>Below are all the news stories where you can select which one you would like to delete</p>
  </section>
@endsection
