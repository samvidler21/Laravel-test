@extends('layouts.master')

@section('title', 'View All News')

@section('content')
<section>
    <h1>View All News</h1>
    <p>View all the news stories below.</p>
</section>
            @endsection
