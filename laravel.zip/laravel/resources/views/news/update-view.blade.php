@extends('layouts.master')

@section('title', 'View All News')

@section('content')
<section>
    <h1>Update a News story</h1>
    <p>Below are all the news stories where you can select which one you would like to update</p>
  </section>
@endsection
